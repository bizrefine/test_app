//
//  ViewController.swift
//  playpouse
//
//  Created by NESS on 2015/07/21.
//  Copyright (c) 2015年 NESS. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    @IBOutlet weak var volume: UILabel!
    @IBOutlet weak var speed: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var btnPlayPause: UIButton!
    @IBOutlet weak var sliderTime: UISlider!
    
//    var audioPath = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("test", ofType: "mp3")!)
    var audioPath:AVAudioPlayer?
    var player = AVAudioPlayer()
    var timer = NSTimer()
    
    
    @IBAction func btnPlayPause(sender: UIButton) {
        if player.playing {
            player.pause()
            btnPlayPause.setTitle("PLAY", forState: UIControlState.Normal)
        }
        else {
            player.play()
            btnPlayPause.setTitle("PAUSE", forState: UIControlState.Normal)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //サウンドファイルを読み込む
        let soundPath = NSBundle.mainBundle().pathForResource("test", ofType: "mp3")!
        let url:NSURL? = NSURL.fileURLWithPath(soundPath)
        do {
            //↓playerに読み込んだmp3ファイルへのパスを設定する
            player = try AVAudioPlayer(contentsOfURL:url!)
        } catch _ {
            audioPath = nil
        }
        player.prepareToPlay()
        sliderTime.maximumValue = Float(player.duration)
        time.text = formatTimeString(player.duration)
        player.enableRate = true
        timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: Selector("updatePlayingTime"), userInfo: nil, repeats: true)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func slidingVolume(sender: UISlider) {
        player.volume = sender.value
        volume.text = "volume : " + "\(Int((sender.value)*100))"
    }
    
    @IBAction func slidingSpeed(sender: UISlider) {
        player.rate = (sender.value)*2
        let speedMater = Int((sender.value)*200)
        let sm = String(format: "%02d", speedMater)
        speed.text = "Speed : " + "\(sm)" + "%"
    }
    
    @IBAction func slidingTime(sender: UISlider) {
        player.currentTime = Double(sliderTime.value)
        self.updatePlayingTime()
    }
    
    func updatePlayingTime () {
        sliderTime.value = Float(player.currentTime)
        time.text = "time : " + "\(formatTimeString(player.currentTime))" + " / " + "\(formatTimeString(player.duration))"
    }
    
    func formatTimeString(t: Double) -> String {
        let m :Int = Int(t / 60)
        let s :Int = Int(t) - (m * 60)
        let str = String(format: "%02d:%02d", m, s)
        return str
    }
    
}

